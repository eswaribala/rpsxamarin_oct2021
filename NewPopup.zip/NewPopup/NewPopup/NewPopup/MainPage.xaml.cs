﻿using System;
using Xamarin.Forms;

namespace NewPopup
{
	public partial class MainPage : TabbedPage
	{
		public MainPage ()
		{
			InitializeComponent ();
		}
	}
}

