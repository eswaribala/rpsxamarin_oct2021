﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace XamarinAnimations.Views
{
    public partial class Title : ContentView
    {
        public Title()
        {
            InitializeComponent();
        }
    }
}
