﻿using Xamarin.Forms;

namespace ExpanderDemos.Views
{
    public partial class BasicExpanderContentTemplatePage : ContentPage
    {
        public BasicExpanderContentTemplatePage()
        {
            InitializeComponent();
        }
    }
}
