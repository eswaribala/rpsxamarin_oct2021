﻿using Xamarin.Forms;

namespace ExpanderDemos.Views
{
    public partial class EmbeddedExpanderPage : ContentPage
    {
        public EmbeddedExpanderPage()
        {
            InitializeComponent();
        }
    }
}
