﻿using MasterDetailDemo.Models;
using MasterDetailDemo.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MasterDetailDemo
{
    public partial class MainPage : MasterDetailPage
    {
        public List<MasterPageItem> menuList
        {
            get;
            set;
        }
        public MainPage()
        {
          InitializeComponent();
            menuList = new List<MasterPageItem>();
            // Adding menu items to menuList and you can define title ,page and icon  
            menuList.Add(new MasterPageItem()
            {
                Title = "Home",
                Icon = "homeicon.png",
                TargetType = typeof(TestPage1)
            });
            menuList.Add(new MasterPageItem()
            {
                Title = "Contact",
                Icon = "contacticon.png",
                TargetType = typeof(TestPage2)
            });
            menuList.Add(new MasterPageItem()
            {
                Title = "About",
                Icon = "abouticon.png",
                TargetType = typeof(TestPage3)
            });
            menuList.Add(new MasterPageItem()
            {
                Title = "Main",
                Icon = "icon.png",
                TargetType = typeof(TestPage1)
            });
            // Setting our list to be ItemSource for ListView in MainPage.xaml  
            navigationDrawerList.ItemsSource = menuList;
            // Initial navigation, this can be used for our home page  
            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(TestPage1)));
        }

        private void OnMenuItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            var item = (MasterPageItem)e.SelectedItem;
            Type page = item.TargetType;
            Detail = new NavigationPage((Page)Activator.CreateInstance(page));
            IsPresented = false;
        }
    }
}
